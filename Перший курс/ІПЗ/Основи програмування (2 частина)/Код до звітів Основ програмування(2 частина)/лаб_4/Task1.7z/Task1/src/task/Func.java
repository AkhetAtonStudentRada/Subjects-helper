package task;

import java.util.Scanner;

public class Func {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Input x and n: \n");

        double x = scan.nextDouble();
        int n = scan.nextInt();

        if (n <= 1) {
            System.err.println("Incorrect data");
        }
        double sum = 0;
        double mult = 1;

        label:
        for (int i = 1; i <= (n-1); i++)
        {
            for (int j = 0; j <= n; j++)
            {
                if (i == j + x) {
                    continue label;
                }
                if (j + i == 0){
                    System.err.println("Error. Division by zero");
                    break label;
                }
                sum += i/(j+x);
            }
            mult *= sum;
        }
        System.out.println("y = " + mult);
    }
}